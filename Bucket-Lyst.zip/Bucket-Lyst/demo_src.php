<?php  
session_start();
include "conn.php";
$name = $_SESSION['namee'];
?> 
 
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="post" action="demo_src.php">
	<h1>SUBMIT !!</h1>
	<input type="submit" name="submit">

</form>

</body>
</html>

<?php  
$n = "what.jpg";
$i='./uploads/admin/finish/admin_c2.jpg';
if (isset($_POST['submit'])) {
	$op = shell_exec("python analyzer.py $i");
	echo $op;
	}

?>