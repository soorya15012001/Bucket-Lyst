<?php  
session_start();
include "conn.php";
$name = $_SESSION['namee'];
$email = $_SESSION['email'];
$pswd = $_SESSION['pswd'];
?>
<?php  


if (isset($_POST['submit'])) 
{
if(move_uploaded_file($_FILES['profile']['tmp_name'],"uploads/".$name."/avatar.jpg"))
{

    $bio = $_POST['bio'];
    $emaill = $_POST['email'];


    
    $res=mysqli_query($conn, "UPDATE user SET user = '". $_POST['user'] ."' WHERE email = '". $_SESSION['email']."'") or die(mysqli_error($conn));
    $res2=mysqli_query($conn, "UPDATE user SET des='$bio' WHERE pswd = '$pswd' and name = '$name'");

    if ($res) {
        header("Location: profile.php"); 
    }
    else
        echo "<br>FAILEDD!!!";

}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Profile | Vietgram</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/menu.css"> 



</head>

<body style="background-image: url(main_back.png); background-repeat: no-repeat; background-position: center; background-size: cover;" id="body">
    <nav class="navigation" style="background-color: #d66e00;">
        <div class="navigation__column">
            <a href="feed.php" style="margin-left: -90px">
                <!-- Master branch comment -->
                <img src="logo.png" height="200px" width="100px" style="border:2px solid;box-shadow: 5px 10px 10px #35768c; " />
                <img src="https://i.imgur.com/2RasCzn.gif" />
            </a>
        </div>

        <div class="navigation__column" style="margin-right: 470px ;box-shadow: 5px 5px 10px #35768c; ">
            <i class="fa fa-search"></i>
            <input type="text" placeholder="Search">
        </div>

           <div class="menu" style="margin-right: 100px; margin-top: 10px;">
   <input type="checkbox" href="#" class="expandmenu" name="expandmenu" id="expandmenu" />
   <label class="expandmenu-button" for="expandmenu">
    <span class="lines first-line"></span>
    <span class="lines sec-line"></span>
    <span class="lines third-line"></span>
   </label>

   <a href=""></a><a href=""></a>
      <a href="profile.php" class="menu-item col6"> <i class="fa fa-user-o fa-lg"></i> </a>
      <a href="explore.php" class="menu-item col2"> <i class="fa fa-heart-o fa-lg"></i> </a>
      <a href="map.php" class="menu-item col3"> <i class="fa fa-map-o fa-lg" ></i> </a>
  </div>
 </nav>


    <main id="edit-profile" >
        <div class="edit-profile__container" style="background-color: #ebedff; border:2px solid;box-shadow: 5px 5px 10px #17008a;padding-top: 0px" >
            <header class="edit-profile__header" style="border:3px solid;">
                <div class="edit-profile__avatar-container">
                    <?php echo "<img src='uploads/".$name."/avatar.jpg' height='150px' width='150px' />" ?>

                </div>
                <h4 class="edit-profile__username"><?php  echo "<p>". $_SESSION["userr"]." </p>"; ?></h4>
            </header>



            <form method="post" action="edit_profile.php" class="edit-profile__form" enctype="multipart/form-data">

                <div class="form__row">
                    <label for="full-name" class="form__label">Profile Image:</label>
                    <input name="profile"  type="file" id="profile" alt="Login" style="border:2px solid black;"/>
                </div>

                <div class="form__row">
                    <label for="full-name" class="form__label">Name:</label>
                    <input name="namy" id="full-name" type="text" class="form__input" style="border:2px solid black;"/>
                </div>
                <div class="form__row">
                    <label for="user-name" class="form__label">Username:</label>
                    <input name="user" id="user-name" type="text" class="form__input" style="border:2px solid black;"/>
                </div>
                <div class="form__row">
                    <label for="website" class="form__label">Website:</label>
                    <input name="site" id="website" type="url" class="form__input" style="border:2px solid black;"/>
                </div>
                <div class="form__row">
                    <label for="bio" class="form__label">Bio:</label>
                    <textarea name="bio" id="bio" style="border:2px solid black;"></textarea>
                </div>
                <div class="form__row">
                    <label for="email" class="form__label">Email:</label>
                    <input name="email" id="email" type="email" class="form__input" style="border:2px solid black;"/>
                </div>
                <div class="form__row">
                    <label for="phone" class="form__label">Phone Number:</label>
                    <input name="phno" id="phone" type="tel" class="form__input" style="border:2px solid black;"/>
                </div>
                <div class="form__row" >
                    <label for="gender" class="form__label">Gender:</label>
                    <select name="gender" id="gender" style="border:2px solid black; background-color: white">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="cant">Can't remember</option>
                    </select>
                </div>
                <input type="submit" value="submit" name="submit">

            </form>





        </div>
    </main>

<br><br>

</body>




</html>