<?php  
session_start();
include "conn.php";
$name = $_SESSION['namee'];
$email = $_SESSION['email'];
$pswd = $_SESSION['pswd'];
$follow = $_SESSION["follow"];
?>

<?php 

$sql = mysqli_query($conn,"SELECT * FROM user where name = '$name'");
if (mysqli_num_rows($sql) > 0) 
                      {
                          while($row = mysqli_fetch_assoc($sql)) 
                          {
                          $fall = $row["follow"];
                          }
                          
                      }



if (isset($_POST['submit'])) {
    $res2=mysqli_query($conn,"UPDATE user SET  follow = '$fall".$follow."_' where name = '$name'");
    if ($res2) 
        header("Location: feed.php"); 
    else
        echo "<br>FAIL!!";

}





?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Profile | Vietgram</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/styles.css">
        <link rel="stylesheet" href="css/menu.css"> 
</head>

<body style="background-image: url(main_back.png); background-repeat: no-repeat; background-position: center; background-size: cover;" id="body">
    <nav class="navigation" style="background-color: #d66e00;">
        <div class="navigation__column">
            <a href="feed.php" style="margin-left: -90px">
                <!-- Master branch comment -->
                <img src="logo.png" height="200px" width="100px" style="border:2px solid;box-shadow: 5px 10px 10px #35768c; " />
                <img src="https://i.imgur.com/2RasCzn.gif" />
            </a>
        </div>

        <div class="navigation__column" style="margin-right: 470px ;box-shadow: 5px 5px 10px #35768c; ">
            <i class="fa fa-search"></i>
            <input type="text" placeholder="Search">
        </div>

           <div class="menu" style="margin-right: 100px; margin-top: 10px;">
   <input type="checkbox" href="#" class="expandmenu" name="expandmenu" id="expandmenu" />
   <label class="expandmenu-button" for="expandmenu">
    <span class="lines first-line"></span>
    <span class="lines sec-line"></span>
    <span class="lines third-line"></span>
   </label>

   <a href=""></a><a href=""></a>
      <a href="profile.php" class="menu-item col6"> <i class="fa fa-user-o fa-lg"></i> </a>
      <a href="explore.php" class="menu-item col2"> <i class="fa fa-heart-o fa-lg"></i> </a>
      <a href="map.php" class="menu-item col3"> <i class="fa fa-map-o fa-lg" ></i> </a>


  </div>

    </nav>

    <main id="profile">
        <div class="photo" style="background-color: #ebedff; border:2px solid;box-shadow: 5px 5px 10px #17008a;padding-top: 10px; padding-left: 210px; padding-right: 210px;">
        <header class="profile__header">
            <div class="profile__column">
                <?php echo "<img src='uploads/".$follow."/avatar.jpg' height='150px' width='150px' />" ?>
                
            </div>
            <div class="profile__column">
                <div class="profile__title">
                    <h1 class="profile__username" style="font-weight: inherit;font-size: 30px"><?php 

                    $sql = mysqli_query($conn, "SELECT * FROM user WHERE name = '$follow'");
                      if (mysqli_num_rows($sql) > 0) 
                      {
                          while($row = mysqli_fetch_assoc($sql)) 
                          {
                          $abc = $row["user"];
                          }
                          
                      }


                    echo $abc;?></h1>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;
                    <form method="POST" action="follow_profile.php">
                    <input type="submit" name="submit" value="Follow">
                    </form>
                </div>
                <ul class="profile__stats">
                    <li class="profile__stat">
                        <span class="stat__number"><?php 
                        $res1=mysqli_query($conn,"select * from ". "$follow");
                        echo mysqli_num_rows($res1);
                        ?></span> Item-Lysts
                    </li>
                    <li class="profile__stat">
                        <span class="stat__number">
                        <?php 
                        $res2=mysqli_query($conn,"select * from "."$follow"." where stat is null");
                        echo (mysqli_num_rows($res1) - mysqli_num_rows($res2));
                        ?>
                        </span> Completed
                    </li>
                    <li class="profile__stat">
                        <span class="stat__number">
                        <?php 
                        echo mysqli_num_rows($res2);
                        ?>                                                        
                        </span> To-Do
                    </li>
                </ul>
                <p class="profile__bio">
                    <span class="profile__full-name">
                        <b>About :-</b><br><br>
                    </span>
                    <p>

                    <?php  


                    $sql = mysqli_query($conn,"select * from user where name = '$follow'");
                    $row = mysqli_fetch_assoc($sql);
                    echo $row['des'];

                    ?>

                    </p><br>
                    
                </p>
            </div>
        </header>
    </div>
    <br><br><br>


<p style="font-size: 50px; background-color: lightblue; color: darkblue; border-radius: 5px; border: 3px solid black">His/Her's Bucket-Lyst</p><br>

            <?php  
            $res3=mysqli_query($conn,"select * from ". "$follow");
            if (mysqli_num_rows($res3) > 0) 
            {
                echo "
                <div class='photo' style='background-color: #545454; border:2px solid;box-shadow: 5px 5px 10px #002f7a; padding: 10px;'>
                <section class='profile__photos'>";
               while($row1 = mysqli_fetch_assoc($res3)) 
               {
                echo "              
                <div class='profile__photo'>
                    <img src='".$row1['image']."' width ='100%' height='100%' style='border: 3px solid #00094f; border-radius: 10px;' />
                    <center><p style='color: white;font-weight: bold;font-size: 20px;px;'>".$row1['title']."</p></center>
                    <div class='profile__photo-overlay'>
                        <span class='overlay__item'>
                            <i class='fa fa-heart'></i>
                            4
                        </span>
                        <span class='overlay__item'>
                            <i class='fa fa-comment'></i>
                            3
                        </span>
                    </div>
                </div>";
                }
            }
            else
            {
                    echo "
                    <div class='photo' style='background-color: #545454; border:2px solid;box-shadow: 5px 5px 10px #002f7a;padding-left: 295px; padding-right: 295px; padding-top: 100px; padding-bottom: 100px'>
                    <section class='profile__photos'>
                    <p style='color: white;font-weight: bold;font-size: 20px;px;'>He has not created a lyst yet !!</p>";
            }




            ?>


        </section>
    </div>

    </main>
<br><br>
</body>

</html>