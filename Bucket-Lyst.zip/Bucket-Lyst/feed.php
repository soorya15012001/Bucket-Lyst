<?php
session_start();
include "conn.php";
$name = $_SESSION['namee'];
$name = $_SESSION['namee'];
$email = $_SESSION['email'];
$pswd = $_SESSION['pswd'];


$res = mysqli_query($conn, "SELECT * FROM user WHERE email='$email' AND pswd ='$pswd'");
  if (mysqli_num_rows($res) > 0) 
  {
      while($row = mysqli_fetch_assoc($res)) 
      {
      $_SESSION["userr"] = $row["user"];
      $_SESSION["fall"] = $row["follow"];
      }
      
  }

if (isset($_POST['addy'])) {
    $_SESSION['lyst'] = $_POST['addy'];
    header('Location: index.php');
}


?>

<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv='X-UA-Compatible' content='ie=edge'>
    <title>Feeds</title>
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
    <link rel='stylesheet' href='css/styles.css'>
    <link rel='stylesheet' href='css/menu.css'> 
    <style type='text/css'>
    	.container {
  position: relative;
  width: 50%;
}

.image {
  opacity: 1;
  display: block;
  width: 200%;  
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 100%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  text-align: center;
}

.container:hover .image {
  opacity: 0.3;
}

.container:hover .middle {
  opacity: 1;
}

.text {
  background-color: #598bff;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
}
    </style>

<script type='text/javascript'>
var l = 0; var l1 = 0;
function display(){
var c = document.getElementById('comment').value
document.getElementById('cmt').innerHTML += '<span><?php echo $_SESSION['userr'];  ?></span>  '+c + '<br>';
}
function display1(){
var c = document.getElementById('comment1').value
document.getElementById('cmt1').innerHTML += '<span>Soorya</span>  '+c + '<br>';
}

function likes(){
l++;var count=1;
    var property = document.getElementById('btn');
    if (count == 0){
        property.style.backgroundColor = '#FFFFFF';
        count=1;        
    }
    else{
        property.style.backgroundColor = '#f70800';
        property.style.borderRadius = '100px';
        count=0;
    }
document.getElementById('like1').innerHTML = l +' Likes' ;

}

function likes1(){
l1++;
var count=1;
    var property = document.getElementById('btn1');
    if (count == 0){
        property.style.backgroundColor = '#FFFFFF';
        count=1;        
    }
    else{
        property.style.backgroundColor = '#f70800';
        property.style.borderRadius = '100px';
        count=0;
    }
document.getElementById('like2').innerHTML = l1 +' Likes' ;
}
function add(){
document.getElementById('thing').innerHTML = 'Added to your list!!' ;	
}
function add1(){
document.getElementById('thing1').innerHTML = 'Added to your list!!' ;	
}
</script>

</head>

<body style='background-image: url(main_back.png); background-repeat: no-repeat; background-position: center; background-size: cover;' id='body'>
    <nav class='navigation' style='background-color: #d66e00;'>
        <div class='navigation__column'>
            <a href='feed.php' style='margin-left: -90px'>
                <!-- Master branch comment -->
                <img src='logo.png' height='200px' width='100px' style='border:2px solid;box-shadow: 5px 10px 10px #35768c; ' />
                <img src='https://i.imgur.com/2RasCzn.gif' />
            </a>
        </div>

        <div class='navigation__column' style='margin-right: 470px ;box-shadow: 5px 5px 10px #35768c; '>
            <i class='fa fa-search'></i>
            <input type='text' placeholder='Search'>
        </div>

           <div class='menu' style='margin-right: 100px; margin-top: 10px;'>
   <input type='checkbox' href='#' class='expandmenu' name='expandmenu' id='expandmenu' />
   <label class='expandmenu-button' for='expandmenu'>
    <span class='lines first-line'></span>
    <span class='lines sec-line'></span>
    <span class='lines third-line'></span>
   </label>

   <a href=''></a><a href=''></a>
      <a href='profile.php' class='menu-item col6'> <i class='fa fa-user-o fa-lg'></i> </a>
      <a href='explore.php' class='menu-item col2'> <i class='fa fa-heart-o fa-lg'></i> </a>
      <a href='map.php' class='menu-item col3'> <i class='fa fa-map-o fa-lg' ></i> </a>
  </div>
 </nav>


    <section>
    <article>
    <main id='feed'>



        <div class='photo' style='background-color: #ebedff; border:2px solid;box-shadow: 5px 10px 10px #17008a;'>
            <header class='photo__header' style='border: 3px solid black;'>
                <img src='logo.png' class='photo__avatar' />
                <div class='photo__user-info'>
                    <span class='photo__author'>Bucket-Lyst</span>
                    <span class='photo__location'>Somewhere in your minds</span>
                </div>
            </header>
        <form method='POST' action='feed.php'>
            <div class='container' >
			  <img src='task.png' alt='Avatar' class='image' height="420px">
			  <div class='middle'>
			    <button class='text' onclick='add()' name='addy' value='sky-diving' ><p id='thing'>Make a Lyst</p></button>
			  </div>
			</div>
        </form>
            <div class='photo__info'>
                <div class='photo__actions'>
                    <span class='photo__action'>
                        <button id='btn'class='fa fa-heart-o fa-lg' onclick='likes()' style='border:none;background:none;padding:0;outline: none;'></button>
                    </span>
                    <span class='photo__action'>
                        <i class='fa fa-comment-o fa-lg'></i>
                    </span>
                </div>
                <p id='like' class='photo__likes'></p>
                <ul class='photo__comments'>
                    <li class='photo__comment'>
                        <span class='photo__comment-author'>Bucket-Master</span> Come On Start making one !!
                    </li>
                    <div id='cmt'></div>
                    
                </ul>
                <span class='photo__time-ago'>2 hours ago</span>
                <div class='photo__add-comment-container'>
                    <textarea id='comment' placeholder='Add a comment...' style='border: 2px solid #060078;box-shadow: 2px 2px 10px #666666;'></textarea>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <button onclick='display()' style='background: #f0daad;'>Post</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    <i class='fa fa-ellipsis-h'></i>
                </div>
            </div>
        </div>



<?php  

$res1=mysqli_query($conn,"select * from ". "$name" . " where stat = 1");
if (mysqli_num_rows($res1) > 0) 
{
   while($row = mysqli_fetch_assoc($res1)) {


   	echo "  <div class='photo' style='background-color: #ebedff; border:2px solid;box-shadow: 5px 10px 10px #17008a;'>
            <header class='photo__header' style='border: 3px solid black;'>
                <img src='"."uploads/".$name."/avatar.jpg"."' class='photo__avatar' />
                <div class='photo__user-info'>
                    <span class='photo__author'>".$_SESSION['userr']."</span>
                    <span class='photo__location'>".$row['title']."</span>
                </div>
            </header>
        <form method='POST' action='feed.php'>
            <div class='container' >
			  <img src='".$row['image']."' alt='Avatar' class='image'>
			  <div class='middle'>
			    <button class='text' onclick='add()' name='addy'><p id='thing'>".$row['title']."</button>
			  </div>
			</div>
        </form>
            <div class='photo__info'>
                <div class='photo__actions'>
                    <span class='photo__action'>
                        <button id='btn'class='fa fa-heart-o fa-lg' onclick='likes()' style='border:none;background:none;padding:0;outline: none;'></button>
                    </span>
                    <span class='photo__action'>
                        <i class='fa fa-comment-o fa-lg'></i>
                    </span>
                </div>
                <p id='like' class='photo__likes'></p>
                <ul class='photo__comments'>
                    <li class='photo__comment'>
                        <span class='photo__comment-author'>".$_SESSION['userr']."</span>"." ".$row['descr']."
                    </li>
                    <div id='cmt'></div>
                    
                </ul>
                <span class='photo__time-ago'>2 hours ago</span>
                <div class='photo__add-comment-container'>
                    <textarea id='comment' placeholder='Add a comment...' style='border: 2px solid #060078;box-shadow: 2px 2px 10px #666666;'></textarea>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <button onclick='display()' style='background: #f0daad;'>Post</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    <i class='fa fa-ellipsis-h'></i>
                </div>
            </div>
        </div>";





	}
}



$fall = explode("_", $_SESSION["fall"]);

foreach ($fall as $key) {

$res2=mysqli_query($conn,"select * from ". "$key" . " where stat = 1");
if ($res2) 
{
   while($row = mysqli_fetch_assoc($res2)) {


    echo "  <div class='photo' style='background-color: #ebedff; border:2px solid;box-shadow: 5px 10px 10px #17008a;'>
            <header class='photo__header' style='border: 3px solid black;'>
                <img src='"."uploads/".$key."/avatar.jpg"."' class='photo__avatar' />
                <div class='photo__user-info'>
                    <span class='photo__author'>".$key."</span>
                    <span class='photo__location'>".$row['title']."</span>
                </div>
            </header>
        <form method='POST' action='feed.php'>
            <div class='container' >
        <img src='".$row['image']."' alt='Avatar' class='image'>
        <div class='middle'>
          <button class='text' onclick='add()' name='addy'><p id='thing'>".$row['title']."</button>
        </div>
      </div>
        </form>
            <div class='photo__info'>
                <div class='photo__actions'>
                    <span class='photo__action'>
                        <button id='btn'class='fa fa-heart-o fa-lg' onclick='likes()' style='border:none;background:none;padding:0;outline: none;'></button>
                    </span>
                    <span class='photo__action'>
                        <i class='fa fa-comment-o fa-lg'></i>
                    </span>
                </div>
                <p id='like' class='photo__likes'></p>
                <ul class='photo__comments'>
                    <li class='photo__comment'>
                        <span class='photo__comment-author'>".$key."</span>"." ".$row['descr']."
                    </li>
                    <div id='cmt'></div>
                    
                </ul>
                <span class='photo__time-ago'>2 hours ago</span>
                <div class='photo__add-comment-container'>
                    <textarea id='comment' placeholder='Add a comment...' style='border: 2px solid #060078;box-shadow: 2px 2px 10px #666666;'></textarea>
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <button onclick='display()' style='background: #f0daad;'>Post</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    <i class='fa fa-ellipsis-h'></i>
                </div>
            </div>
        </div>";
}
}
else
continue;
}








?>





    </main>
    </article>
    <aside>

    </aside>
    </section>

</body>

</html>

