<?php
session_start();
include "conn.php";
?>
<!DOCTYPE HTML>
<html lang="en" >
<html>
<head>
  <title>Sign Up</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="signup_style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>  
  <style type="text/css">
    #login-card{
    width:350px;
    border-radius: 25px;
    margin:150px auto;
  
}
  </style>
</head>

<body class="body" style="background-image: url(backg.png); background-repeat: no-repeat; background-position: center; background-size: cover;">

<img src="logo.png" width="120px" height="120px">
<div id="login-card" class="card" style="margin-top: -45px;">
<div class="login-page">
  <center><img src="https://i.imgur.com/2RasCzn.gif" style="background-color: white; padding-top: 25px;padding-bottom: 30px; border-radius: 25px;"></center>

  <div class="form">
    <h2><b style="color: #ffa436">Sign-Up form</b></h2>

    <form method="POST" action="signup.php">
      <input type="text" placeholder="full name" name="name">
      <input type="text" placeholder="email address" name="email">
      <input type="text" placeholder="pick a username" name="username">
      <input type="password" placeholder="set a password" name="pswd">     
      <br><br>
      <input type="submit" id="button" class="btn btn-primary deep-purple btn-block" name="submit" style="background-color: #32ba8b; color: white">
    </form>

  </div>
</div>
</div>

<?php

if (isset($_POST['submit'])) 
{
  $name = $_POST['name'];
  $username = $_POST['username'];
  $email = $_POST['email'];
  $pswd = $_POST['pswd'];
  
  
  $res = mysqli_query($conn, "INSERT INTO user (name, email, user, pswd) VALUES ('$name','$email','$username','$pswd')");
  if ($res) 
  {
     
      $crt = mysqli_query($conn, "CREATE TABLE ". "$name" ." (title VARCHAR(100), descr VARCHAR(100), url VARCHAR(100), image VARCHAR(100), stat INT(2) NULL)");

      if ($crt) {
        $dest = "uploads/".$name."/avatar.jpg";
        echo $name;
        mkdir("uploads/".$name);
        mkdir("uploads/".$name."/finish");
        copy("avatar.jpg",$dest);        
        echo "SUCCESS";
        header("Location: login.php"); 

      } else {
        echo "<br>ERROR :- " . mysqli_error($conn);;
      }

  }
  else
    echo "<h1 style='background: lightblue; color: darkblue; margin-left: 400px; margin-right: 390px; margin-top: -110px'>Server Error!!</h1>";
}




?>




</body>
</html>

