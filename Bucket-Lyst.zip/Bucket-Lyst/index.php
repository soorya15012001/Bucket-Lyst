<?php  
session_start();
include "conn.php";
$name = $_SESSION['namee'];

?>					


<html>
 
<head>
        <title>Bucket-List</title>
         
<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
 
     <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Explore | Vietgram</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/menu.css">    
    

 <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700i" rel="stylesheet">
 
 
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
		<script src="booklet/jquery.easing.1.3.js" type="text/javascript"></script>
		<script src="booklet/jquery.booklet.1.1.0.min.js" type="text/javascript"></script>

		<link href="booklet/jquery.booklet.1.1.0.css" type="text/css" rel="stylesheet" media="screen" />
		 
		 
		 <style>
         
.booklet           {
	width:900px;
	height:607px;
	position:relative;
	margin:0 auto 10px;
	-moz-box-shadow:0px 0px 1px #fff;
	-webkit-box-shadow:0px 0px 1px #fff;
	box-shadow:0px 0px 1px #fff;
	-moz-border-radius:10px;
	-webkit-border-radius:10px;
	border-radius:10px;
}
.booklet .b-wrap-left  {
	background:#fff url(images/left_bg.jpg) no-repeat top left;
	-webkit-border-top-left-radius: 10px;
	-webkit-border-bottom-left-radius: 10px;
	-moz-border-radius-topleft:10px;
	-moz-border-radius-bottomleft: 10px;
	border-top-left-radius: 10px;
	border-bottom-left-radius: 10px;
}
.booklet .b-wrap-right {
	background:#efefef url(images/right_bg.jpg) no-repeat top left;
	-webkit-border-top-right-radius: 10px;
	-webkit-border-bottom-right-radius: 10px;
	-moz-border-radius-topright: 10px;
	-moz-border-radius-bottomright: 10px;
	border-top-right-radius: 10px;
	border-bottom-right-radius: 10px;
}
.booklet .b-counter {
	bottom:10px;
	position:absolute;
	display:block;
	width:90%;
	height:20px;
	border-top:1px solid #ddd;
	color:#222;
	text-align:center;
	font-size:12px;
	padding:5px 0 0;
	background:transparent;
	-moz-box-shadow:0px -1px 1px #fff;
	-webkit-box-shadow:0px -1px 1px #fff;
	box-shadow:0px -1px 1px #fff;
	opacity:0.8;
}
.book_wrapper{
	margin:0 auto;
	padding-top:50px;
	width:905px;
	height:540px;
	position:relative;
	background:transparent url(images/bg.png) no-repeat 9px 27px;
}
.book_wrapper h1{
	color:orange;
	margin:5px 5px 5px 15px;
	font-size:24px;
	background:transparent url(images/h1.png) no-repeat bottom left;
	padding-bottom:7px;
    text-transform: uppercase;
    font-weight: normal;
}
.book_wrapper p{
	font-size:15px;
	margin:5px 5px 5px 15px;
}
.book_wrapper a.article,
.book_wrapper a.demo{
	background:transparent url(images/circle.png) no-repeat 50% 0px;
	display:block;
	width:95px;
	height:41px;
	text-decoration:none;
	outline:none;
	font-size:16px;
	color:#555;
	float:left;
	line-height:41px;
	padding-left:47px;
}
.book_wrapper a.demo{
	margin-left:50px;
}
.book_wrapper a.article:hover,
.book_wrapper a.demo:hover{
	background-position:50% -41px;
	color:#13386a;
}
.book_wrapper img{
	margin:10px 0px 5px 35px;
	width:300px;
	padding:4px;
	border:1px solid #ddd;
	-moz-box-shadow:1px 1px 1px #fff;
	-webkit-box-shadow:1px 1px 1px #fff;
	box-shadow:1px 1px 1px #fff;
}
.booklet .b-wrap-right img{
	border:1px solid #E6E3C2;
}
a#next_page_button,
a#prev_page_button{
	display:none;
	position:absolute;
	width:41px;
	height:40px;
	cursor:pointer;
	margin-top:-20px;
	top:50%;
	background:transparent url(images/buttons.png) no-repeat 0px -40px;
}
a#prev_page_button{
	left:-30px;
}
a#next_page_button{
	right:-30px;
	background-position:-41px -40px;
}
a#next_page_button:hover{
	background-position:-41px 0px;
}
a#prev_page_button:hover{
	background-position:0px 0px;
}







input[type=text],
    input[type=password] {
        width: 100%;
        padding: 12px 20px;
        margin: 8px 0;
        display: inline-block;
        border: 2px solid #ccc;
        box-sizing: border-box;
    }
    /* set a style for all buttons*/
    button {
        background-color: green;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        cursor: pointer;
        width: 100%;
    }
    /*set styles for the cancel button*/
    .cancelbtn {
        padding: 14px 20px;
        background-color: #FF2E00;
    }
    /*float cancel and signup buttons and add an equal width*/
    .cancelbtn,
    .signupbtn {
        float: left;
        width: 50%
    }
    /*add padding to container elements*/
    .container {
        padding: 16px;
    }
    /*define the modal’s background*/
     
    .modal {
        display: none;
        position: fixed;
        z-index: 1000000;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgb(0, 0, 0);
        background-color: rgba(0, 0, 0, 0.4);
        padding-top: 60px;
    }
    /*define the modal-content background*/
     
    .modal-content {
        background-color: #fefefe;
        margin: 5% auto 15% auto;
        border: 1px solid #888;
        width: 80%;
    }
    /*define the close button*/
     
    .close {
        position: absolute;
        right: 35px;
        top: 15px;
        color: #000;
        font-size: 40px;
        font-weight: bold;
    }
    /*define the close hover and focus effects*/
     
    .close:hover,
    .close:focus {
        color: red;
        cursor: pointer;
    }
     
    .clearfix::after {
        content: "";
        clear: both;
        display: table;
    }
     
    @media screen and (max-width: 300px) {
        .cancelbtn,
        .signupbtn {
            width: 100%;
        }
    }



 
    
    
         </style>
		 
    </head>
<body style="background-image: url(main_back.png); background-repeat: no-repeat; background-position: center; background-size: cover;" id="body">


<nav class="navigation" style="background-color: #d66e00;">
  <div class="navigation__column">
  		<a href="feed.php" style="margin-left: -90px">
        <img src="logo.png" height="200px" width="100px" style="border:2px solid;box-shadow: 5px 10px 10px #35768c; " />
        <img src="https://i.imgur.com/2RasCzn.gif" />
        </a>
  </div>

  <div class="navigation__column" style="margin-right: 470px ;box-shadow: 5px 5px 10px #35768c; ">
        <i class="fa fa-search"></i>
        <input type="text" placeholder="Search">
  </div>
  
  <div class="menu" style="margin-right: 100px; margin-top: 10px;">
	   <input type="checkbox" href="#" class="expandmenu" name="expandmenu" id="expandmenu" />
	   <label class="expandmenu-button" for="expandmenu">
	    	<span class="lines first-line"></span>
	    	<span class="lines sec-line"></span>
	    	<span class="lines third-line"></span>
	   </label>

	   <a href=""></a><a href=""></a>
	      <a href="profile.php" class="menu-item col6"> <i class="fa fa-user-o fa-lg"></i> </a>
	      <a href="explore.php" class="menu-item col2"> <i class="fa fa-heart-o fa-lg"></i> </a>
	      <a href="map.php" class="menu-item col3"> <i class="fa fa-map-o fa-lg" ></i> </a>
  </div>
</nav>	
<table>
<tr>
	<td style="text-align: center; vertical-align: middle;padding-left: 50px"><center>
    		<a href="#" onclick="formy()" ><img src="https://images.cooltext.com/5460723.png" width='300px' style="border: 3px solid; background-color: lightblue; border-radius: 40px;"></a>
        </center></td>

<td style="padding-left: 100px">
    	

        <div id="id01" class="modal" data-backdrop="false">


		<form class="modal-content animate" method="POST" action="index.php" enctype="multipart/form-data">
			<div class="container">
				<label><b>Image</b></label><br><br>
				<input name="img" type="file" placeholder="Add an image" id="image">
				<br><br>
				<label><b>Title</b></label>
				<input name="title" type="text" placeholder="Enter Title" id="title" required>
				<label><b>Description</b></label>
				<input name="desc" type="text" placeholder="Enter Description" id="desc">
				<label><b>Link</b></label>
				<input name="link" type="text" placeholder="Enter a supporting link" id="link">				
				
				<div class="clearfix">
					<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
					
					<input type="submit" name="submit" style="background-color: green; margin-top: 8px;padding-bottom: 14px; padding-top: 14px; padding-left: 269px;padding-right: 269px;color: white">
				</div>
			</div>
		</form>
		</div>

	<?php  
echo "<div class='book_wrapper'>
			<a id='next_page_button'></a>
			<a id='prev_page_button'></a>
	  <div id='mybook' style='display:none;'>
	  <div class='b-load'>";


if (isset($_POST['submit'])) 
{
if(move_uploaded_file($_FILES['img']['tmp_name'],"./uploads/".$_SESSION['namee']."/".$_SESSION['namee']."_".$_FILES['img']['name']))
{
$des = $_POST['desc'];
$link = $_POST['link'];
$title = $_POST['title'];
$image = "uploads/".$_SESSION['namee']."/".$_SESSION['namee']."_".$_FILES['img']['name'];
$res = mysqli_query($conn, "INSERT INTO " . "$name" . " (title, descr, url, image) VALUES ('$title','$des','$link','$image')");
if ($res) 
	echo "SUCCESS!!";
else
	echo "FAILED TO UPDATE DATA-BASE!!";
}
else
echo "FAILED TO UPLOAD IMAGE !!"; 
}

$res1=mysqli_query($conn,"select * from ". "$name");
if (mysqli_num_rows($res1) > 0) 
{
   while($row = mysqli_fetch_assoc($res1)) {
    echo "<div>
			<img src='".$row['image']."' alt='' />
			<h1>".$row['title']."</h1>
			<p>".$row['descr']."</p>
			<a href='".$row['url']."' class='article'>Link</a>
		</div>";
	}
}

echo "</div>
	</div>
	</div>";

?>	

	</td>
	</tr>
    </table>
        <script type="text/javascript">

			$(function() {
				var $mybook 		= $('#mybook');
				var $bttn_next		= $('#next_page_button');
				var $bttn_prev		= $('#prev_page_button');
				var $loading		= $('#loading');
				var $mybook_images	= $mybook.find('img');
				var cnt_images		= $mybook_images.length;
				var loaded			= 0;
				 
				$mybook_images.each(function(){
					var $img 	= $(this);
					var source	= $img.attr('src');
					$('<img/>').load(function(){
						++loaded;
						if(loaded == cnt_images){
							$loading.hide();
							$bttn_next.show();
							$bttn_prev.show();
							$mybook.show().booklet({
								name:               null,                            //  
								width:              800,                             //  
								height:             500,                             //   
								speed:              600,                             //  
								direction:          'LTR',                           //  
								next:               $bttn_next,          			//  
								prev:               $bttn_prev,          			//  
								                       
							});
							Cufon.refresh();
						}
					}).attr('src',source);
				});
				
			});

			function add(){
				var img = "images/5.jpg";
				var head = document.getElementById('title').value;
				var desc = document.getElementById('desc').value;
				var link = document.getElementById('link').value;

				document.getElementById('bucket').innerHTML = '<div><img src="'+img+'"/><h1>'+head+'</h1><p>'+desc+'</p><a class="'+"article"+'" href="'+link+'">LINK</a></div>';
			}

			function formy(){
        	var modal = document.getElementById('id01');
			modal.style.display='block'
            if (event.target == modal) {
                modal.style.display = "none";
            }
        	}
			
        </script>
 		

    </body>
 
</html>	