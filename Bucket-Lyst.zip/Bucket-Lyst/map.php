<?php  
session_start();
include "conn.php";
$name = $_SESSION['namee'];
$email = $_SESSION['email'];
$pswd = $_SESSION['pswd'];
$title = array();
$des = array();

$res1=mysqli_query($conn,"select * from ". "$name");
if (mysqli_num_rows($res1) > 0) 
{
   while($row = mysqli_fetch_assoc($res1)) {
      array_push($title, $row['title']);
      array_push($des, $row['descr']);
  }
}
?> 

<?php  
    if (isset($_POST['submit'])) 
    {
      $title1 = $_POST['title1'];
      if(move_uploaded_file($_FILES['img']['tmp_name'], "./uploads/".$_SESSION['namee']."/finish/".$_FILES['img']['name']))
      {
        $i = "./uploads/".$_SESSION['namee']."/finish/".$_FILES['img']['name'];
        $op = shell_exec("python analyzer.py $i");
        $op = substr($op, 1, -2);
        $sent = explode(',', $op);
        
        foreach ($title as $t)  
        {
          foreach ($sent as  $s) 
          {
              similar_text($t,$s,$percent);
              similar_text($title1, $t, $percent2);
              if ($percent>40 or $percent2>40) {
                // echo $t."-->".$s."<br>";
                $res2=mysqli_query($conn,"UPDATE ". "$name" . " SET stat = 1 where title = '$t'");
                // if ($res2) 
                //   echo "<br>SUCCESS!!";
                // else
                //   echo "<br>FAIL!!";
              break;
              }
          }
        }
    }
  }
?>


<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bucket-Lyst</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/menu.css">   
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>



  <script>

  var step = <?php echo (100/mysqli_num_rows($res1));?>;
  var percent=0;
  var direction=1;
  function main() 
  {



      var canvas=document.getElementById('canvas');
      var ctx=canvas.getContext('2d');

      var fps = 60;

      animate();

      function animate() {
         
          if(percent<0){ percent=0; direction=1; };
          if(percent>100){ percent=100; direction=-1; };

          draw(percent);

          setTimeout(function() {
              requestAnimationFrame(animate);
          }, 1000 / fps);



      }


      function draw(sliderValue){

          ctx.clearRect(0,0,canvas.width,canvas.height);
          ctx.lineWidth = 5;

          ctx.beginPath();
          ctx.moveTo(100, 20);
          ctx.lineTo(200, 160);
          ctx.strokeStyle = 'red';
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(200, 160);
          ctx.quadraticCurveTo(230, 200, 250, 120);
          ctx.strokeStyle = 'green';
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(250,120);
          ctx.bezierCurveTo(290, -40, 300, 200, 400, 150);
          ctx.strokeStyle = 'blue';
          ctx.stroke();

          ctx.beginPath();
          ctx.moveTo(400, 150);
          ctx.lineTo(500, 90);
          ctx.strokeStyle = 'gold';
          ctx.stroke();

          var xy;

          if(sliderValue<25){
              var percent=sliderValue/24;
              xy=getLineXYatPercent({x:100,y:20},{x:200,y:160},percent);
          }
          else if(sliderValue<50){
              var percent=(sliderValue-25)/24
              xy=getQuadraticBezierXYatPercent({x:200,y:160},{x:230,y:200},{x:250,y:120},percent);
          }
          else if(sliderValue<75){
              var percent=(sliderValue-50)/24
              xy=getCubicBezierXYatPercent({x:250,y:120},{x:290,y:-40},{x:300,y:200},{x:400,y:150},percent);
          }
          else {
              var percent=(sliderValue-75)/25
              xy=getLineXYatPercent({x:400,y:150},{x:500,y:90},percent);
          }
          drawRect(xy,'red');



      }

      function drawRect(point,color){
          ctx.fillStyle='cyan';
          ctx.strokeStyle='gray';
          ctx.lineWidth=3;
          ctx.beginPath();
          ctx.rect(point.x-13,point.y-8,25,15);
          ctx.fill();
          ctx.stroke();
      }

      function drawDot(point,color){
          ctx.fillStyle=color;
          ctx.strokeStyle='black';
          ctx.lineWidth=3;
          ctx.beginPath();
          ctx.arc(point.x,point.y,8,0,Math.PI*2,false);
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
      }

      // line: percent is 0-1
      function getLineXYatPercent(startPt,endPt,percent) {
          var dx = endPt.x-startPt.x;
          var dy = endPt.y-startPt.y;
          var X = startPt.x + dx*percent;
          var Y = startPt.y + dy*percent;
          return( {x:X,y:Y} );
      }

      // quadratic bezier: percent is 0-1
      function getQuadraticBezierXYatPercent(startPt,controlPt,endPt,percent) {
          var x = Math.pow(1-percent,2) * startPt.x + 2 * (1-percent) * percent * controlPt.x + Math.pow(percent,2) * endPt.x; 
          var y = Math.pow(1-percent,2) * startPt.y + 2 * (1-percent) * percent * controlPt.y + Math.pow(percent,2) * endPt.y; 
          return( {x:x,y:y} );
      }

      // cubic bezier percent is 0-1
      function getCubicBezierXYatPercent(startPt,controlPt1,controlPt2,endPt,percent){
          var x=CubicN(percent,startPt.x,controlPt1.x,controlPt2.x,endPt.x);
          var y=CubicN(percent,startPt.y,controlPt1.y,controlPt2.y,endPt.y);
          return({x:x,y:y});
      }

      // cubic helper formula at percent distance
      function CubicN(pct, a,b,c,d) {
          var t2 = pct * pct;
          var t3 = t2 * pct;
          return a + (-a * 3 + pct * (3 * a - a * pct)) * pct
          + (3 * b + pct * (-6 * b + b * 3 * pct)) * pct
          + (c * 3 - c * 3 * pct) * t2
          + d * t3;
      }

       percent+=direction + step;

      if(percent > 100)
      {
        document.getElementById('disp').innerHTML = 'WOWW!! You have completed your Bucket-Lyst!!!';

      }
  };   

  </script>
</head>
<body style="background-image: url(main_back.png); background-repeat: no-repeat; background-position: center; background-size: cover;" id="body">
    <nav class="navigation" style="background-color: #d66e00;">
        <div class="navigation__column">
            <a href="feed.php" style="margin-left: -90px">
                <!-- Master branch comment -->
                <img src="logo.png" height="200px" width="100px" style="border:2px solid;box-shadow: 5px 10px 10px #35768c; " />
                <img src="https://i.imgur.com/2RasCzn.gif" />
            </a>
        </div>

        <div class="navigation__column" style="margin-right: 470px ;box-shadow: 5px 5px 10px #35768c; ">
            <i class="fa fa-search"></i>
            <input type="text" placeholder="Search">
        </div>

           <div class="menu" style="margin-right: 100px; margin-top: 10px;">
   <input type="checkbox" href="#" class="expandmenu" name="expandmenu" id="expandmenu" />
   <label class="expandmenu-button" for="expandmenu">
    <span class="lines first-line"></span>
    <span class="lines sec-line"></span>
    <span class="lines third-line"></span>
   </label>

   <a href=""></a><a href=""></a>
      <a href="profile.php" class="menu-item col6"> <i class="fa fa-user-o fa-lg"></i> </a>
      <a href="explore.php" class="menu-item col2"> <i class="fa fa-heart-o fa-lg"></i> </a>
      <a href="map.php" class="menu-item col3"> <i class="fa fa-map-o fa-lg" ></i> </a>
  </div>
 </nav>

<center><h1 style="border: 3px solid; font-size: 50px; font-weight: bolder;background-color: lightblue; margin-left: 5px;margin-right: 5px; border-radius: 20px">Your Map of Progress!!</h1></center><br><br><br>

<table>
<tr>

<td style="padding-left: 10px;"><a href="index.php" ><img src="list.jpg" width='300px' style="border: 3px solid; background-color: lightblue; border-radius: 40px;"></a></td>

<td>
  <div class="edit-profile__container" style="background-color: #ebedff;box-shadow: 5px 5px 10px #17008a;margin-left: 90px; margin-right: 160px; border: 3px solid" >

<table style=" padding-right: 200px">
  
  <tr>
    <td>
      <h1 style="font-size: 30px;font-weight: bolder;">Your Map</h1><br>
    </td>
    <td>
      <h1 style="font-size: 30px;font-weight: bolder;padding-left: 50px;padding-right: 50px; background-color: #ff9999;">Upload a Photo</h1><br>
    </td>
  </tr>
  <tr>
    <td style="padding-right: 50px;padding-left: 50px">
        <div class="edit-profile__container" style="background-color: #c4c4c4; border:2px solid;box-shadow: 5px 5px 10px #17008a;padding-left: -10px; padding-right: -100px" >
        <canvas id="canvas" width=600 height=300></canvas>
        </div>
        <br><br>
        <!-- <button onclick="main()">Click</button><br><br> -->
        <h2 id="disp" style="font-weight: bold; font-size: 40px;color: green;"></h2>
        </div>
    </td>

    <form method="POST" action="map.php" enctype="multipart/form-data">
    <td style="background-color: #ff9999;text-align: center; vertical-align: middle;">
      <label style="font-weight: bolder;">Upload your image</label><br><br>
      <input type="file" name="img"><br><br>
      <input type="text" name="title1" placeholder="Give the title" style="margin-left: -85px"><br><br>
      
      <?php  
      $res2=mysqli_query($conn,"select * from "."$name"." where stat is not null");
      $i=0;
      while ($i <mysqli_num_rows($res2)){
        echo "<script> main(); </script>";
        $i = $i + 1;

      }
      ?>

      <input type="submit" name="submit">
    </td>
    </form>


  </tr>

</table>
</td>
</tr>
</table>

</div>
<br><br>
</body>
</html>



