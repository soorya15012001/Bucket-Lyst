<?php
session_start();
include "conn.php";
$name = $_SESSION['namee'];
$email = $_SESSION['email'];
$pswd = $_SESSION['pswd'];

$res = mysqli_query($conn, "SELECT * FROM user WHERE email='$email' AND pswd ='$pswd'");
  if (mysqli_num_rows($res) > 0) 
  {
      while($row = mysqli_fetch_assoc($res)) 
      {
      $_SESSION["userr"] = $row["user"];
      }
      
  }

?>


<?php  
if (isset($_POST['submit'])) {
    $l = $_POST['submit'];
    $a = explode('_', $l)[1];
    $res = mysqli_query($conn, "SELECT * FROM user where name = '$a'");
    if (mysqli_num_rows($res) > 0) 
    {
        $_SESSION["follow"] = $a;

        header("Location: follow_profile.php");
    }
    else{
        echo "<h1>PROFILE NOT PRESENT !!</h1>";
    }

    
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Explore | Vietgram</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/menu.css"> 

</head>


<body style="background-image: url(main_back.png); background-repeat: no-repeat; background-position: center; background-size: cover;" id="body">
    <nav class="navigation" style="background-color: #d66e00;">
        <div class="navigation__column">
            <a href="feed.php" style="margin-left: -90px">
                <!-- Master branch comment -->
                <img src="logo.png" height="200px" width="100px" style="border:2px solid;box-shadow: 5px 10px 10px #35768c; " />
                <img src="https://i.imgur.com/2RasCzn.gif" />
            </a>
        </div>

        <div class="navigation__column" style="margin-right: 470px ;box-shadow: 5px 5px 10px #35768c; ">
            <i class="fa fa-search"></i>
            <input type="text" placeholder="Search">
        </div>

           <div class="menu" style="margin-right: 100px; margin-top: 10px;">
   <input type="checkbox" href="#" class="expandmenu" name="expandmenu" id="expandmenu" />
   <label class="expandmenu-button" for="expandmenu">
    <span class="lines first-line"></span>
    <span class="lines sec-line"></span>
    <span class="lines third-line"></span>
   </label>

   <a href=""></a><a href=""></a>
      <a href="profile.php" class="menu-item col6"> <i class="fa fa-user-o fa-lg"></i> </a>
      <a href="explore.php" class="menu-item col2"> <i class="fa fa-heart-o fa-lg"></i> </a>
      <a href="map.php" class="menu-item col3"> <i class="fa fa-map-o fa-lg" ></i> </a>
  </div>
 </nav>
 <div id="login-card" class="card" style="margin-top: 4px;">
<center style="font-weight: bold;font-size: 50px; background-color: #8629ff; border-radius: 100px;margin-left: 450px;margin-right: 450px;padding: 1px"><h1 style="color: orange;">Requests :</h1></center><br>
</div>

    <main id="explore" >
        <ul class="explore__users">
        <form method="POST" action="explore.php">

            <?php  

            $res1=mysqli_query($conn,"select * from user");
            if (mysqli_num_rows($res1) > 1) 
            {
               while($row = mysqli_fetch_assoc($res1)) 
               {
                    if ($_SESSION["namee"] == $row['name']) {
                        continue;
                    }
                    else{
                     echo 
                        "
                        <li class='explore__user' style='border:2px solid;background-color: #ebedff;box-shadow: 5px 5px 10px #17008a;padding-top: 0px'>               
                            <div class='explore__user-column'>
                                <img src='uploads/".$row['name']."/avatar.jpg' class='explore__avatar'/>
                                <div class='explore__info'>
                                    <span class='explore__username'>".$row['user']."</span>
                                    <span class='explore__full-name'>".$row['des']."</span>
                                </div>
                            </div>
                            <div class='explore__user-column'>
                                <input type='hidden' name='follow' value='".$row['name']."'>
                                <input type='submit' name='submit' value='follow_".$row['name']."'>
                            </div>
                        </li><br>
                        ";
                    }
               }
           }

           else
            echo "<h1 style='font-size: 50px; color: red'>No USERS yet !!</h1>";
           

            ?>


           
        </form>
        </ul>
    </main>




</body>
</html>